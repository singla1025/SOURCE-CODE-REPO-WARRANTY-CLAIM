"""
app/automl_app.py
====================
Streamlit AutoML Predictive Maintenance Dashboard. Dataset-agnostic --
upload AI4I 2020, Steel Plates Faults, Pump Sensor Data, Device Failure
Classification, or similar fault datasets.

All cleaning/training logic lives in src/preprocessing and src/model;
this file is the UI layer plus the @st.cache_* wrappers around it.

Run with:  streamlit run app/automl_app.py   (from the project root)
"""

from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import streamlit as st
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

from src.preprocessing.generic_cleaning import (
    detect_identifier_columns, detect_binary_columns,
    detect_aggregate_leakage, guess_target_column, build_features,
)
from src.model.automl_trainer import train_and_compare as _train_and_compare
from src.evaluation.metrics import get_classification_report, get_confusion_matrix
from src.evaluation.plots import plot_confusion_matrix_heatmap
from src.deployment.inference import top_k_risk_predictions

st.set_page_config(page_title="AutoML Predictive Maintenance Dashboard", layout="wide")

MAX_ROWS_FOR_TRAINING = 50_000


@st.cache_data(show_spinner=False)
def load_data(uploaded_file) -> pd.DataFrame:
    return pd.read_csv(uploaded_file)


@st.cache_data(show_spinner=False)
def cached_build_features(raw_df, cols_to_drop, target_mode, target_col, binary_indicator_cols):
    return build_features(raw_df, cols_to_drop, target_mode, target_col, binary_indicator_cols)


@st.cache_resource(show_spinner=False)
def cached_train_and_compare(X_train, X_test, y_train, y_test):
    return _train_and_compare(X_train, X_test, y_train, y_test)


# ============================================================
# HEADER & UPLOAD
# ============================================================
st.title("🤖 AutoML Predictive Maintenance Dashboard")
st.write(
    "Upload **any** fault/failure-style dataset and this dashboard will clean it, "
    "profile it, race four classifiers against each other, and surface the top-2 "
    "most likely failure modes for every row -- automatically."
)

uploaded_file = st.file_uploader("Upload your dataset (CSV)", type=["csv"])
if uploaded_file is None:
    st.info("Upload a CSV to get started.")
    st.stop()

raw_df = load_data(uploaded_file)
st.success(f"Loaded **{raw_df.shape[0]:,} rows** x **{raw_df.shape[1]} columns**.")
st.dataframe(raw_df.head())


# ============================================================
# STEP 1: CLEANING & TARGET DETECTION
# ============================================================
st.divider()
st.header("Step 1: Cleaning & Target Detection")

id_candidates = detect_identifier_columns(raw_df)
binary_cols_all = detect_binary_columns(raw_df)
aggregate_cols = detect_aggregate_leakage(raw_df, binary_cols_all)
binary_indicator_cols = [c for c in binary_cols_all if c not in aggregate_cols]
auto_drop = sorted(set(id_candidates + aggregate_cols))

cols_to_drop = st.multiselect(
    "Columns to drop (identifiers / leakage)",
    options=list(raw_df.columns), default=auto_drop,
)

remaining_cols = [c for c in raw_df.columns if c not in cols_to_drop]
usable_binary_cols = [c for c in binary_indicator_cols if c not in cols_to_drop]

if len(usable_binary_cols) >= 2:
    target_mode, target_col = "multi_binary", None
    st.info(f"Detected **{len(usable_binary_cols)} binary failure-indicator columns** -> combining into one multi-class target: `{usable_binary_cols}`")
else:
    target_mode = "single"
    guessed_target = guess_target_column(raw_df, exclude=set(cols_to_drop))
    default_idx = remaining_cols.index(guessed_target) if guessed_target in remaining_cols else 0
    target_col = st.selectbox("Confirm the target (label) column", options=remaining_cols, index=default_idx)

df, feature_cols, numeric_cols, categorical_cols, class_names = cached_build_features(
    raw_df, tuple(cols_to_drop), target_mode, target_col, tuple(usable_binary_cols)
)

if len(df) > MAX_ROWS_FOR_TRAINING:
    st.warning(f"Dataset has {len(df):,} rows. Using a stratified sample of {MAX_ROWS_FOR_TRAINING:,} rows so training stays fast.")
    df, _ = train_test_split(df, train_size=MAX_ROWS_FOR_TRAINING, stratify=df["target"], random_state=42)
    df = df.reset_index(drop=True)

st.write(f"**Final feature set ({len(feature_cols)} columns):**", feature_cols)
st.write(f"**Detected classes ({len(class_names)}):**", class_names)


# ============================================================
# STEP 2: AUTOMATED EDA
# ============================================================
st.divider()
st.header("Step 2: Automated Exploratory Data Analysis")

corr_source = df[numeric_cols + ["target"]] if numeric_cols else df[["target"]]
corr = corr_source.corr()
if "target" in corr.columns and len(numeric_cols) >= 1:
    target_corr = corr["target"].drop("target").abs().sort_values(ascending=False)
    top2 = target_corr.index[:2].tolist() if len(target_corr) >= 2 else (numeric_cols * 2)[:2]
else:
    top2 = (numeric_cols * 2)[:2] if numeric_cols else [None, None]

c1, c2 = st.columns(2)
with c1:
    st.subheader("Correlation Heatmap")
    fig, ax = plt.subplots(figsize=(7, 6))
    sns.heatmap(corr, cmap="coolwarm", center=0, ax=ax)
    st.pyplot(fig)
with c2:
    st.subheader(f"Class Separation: {top2[0]} vs {top2[1]}")
    fig2, ax2 = plt.subplots(figsize=(7, 6))
    sns.scatterplot(data=df, x=top2[0], y=top2[1], hue="target", palette="tab10", alpha=0.6, s=30, ax=ax2)
    st.pyplot(fig2)

c3, c4 = st.columns(2)
with c3:
    st.subheader("Target Class Distribution")
    fig3, ax3 = plt.subplots(figsize=(7, 5))
    sns.countplot(x="target", data=df, hue="target", palette="rocket", legend=False, ax=ax3)
    ax3.set_xticks(range(len(class_names))); ax3.set_xticklabels(class_names, rotation=30, ha="right")
    st.pyplot(fig3)
with c4:
    st.subheader(f"{top2[0]} by Class")
    fig4, ax4 = plt.subplots(figsize=(7, 5))
    sns.boxplot(x="target", y=top2[0], data=df, hue="target", palette="mako", legend=False, ax=ax4)
    ax4.set_xticks(range(len(class_names))); ax4.set_xticklabels(class_names, rotation=30, ha="right")
    st.pyplot(fig4)


# ============================================================
# STEP 3: SPLIT & SCALE
# ============================================================
st.divider()
st.header("Step 3: Train / Test Split & Scaling")

X, y = df[feature_cols], df["target"]
try:
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, stratify=y, random_state=42)
except ValueError:
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=42)
    st.warning("A class had too few rows to stratify -- used a plain random split instead.")

scaler = StandardScaler()
X_train_scaled, X_test_scaled = X_train.copy(), X_test.copy()
if numeric_cols:
    X_train_scaled[numeric_cols] = scaler.fit_transform(X_train[numeric_cols])
    X_test_scaled[numeric_cols] = scaler.transform(X_test[numeric_cols])

st.write(f"Train: {X_train_scaled.shape[0]:,} rows | Test: {X_test_scaled.shape[0]:,} rows")


# ============================================================
# STEP 4: AUTOML COMPETITION
# ============================================================
st.divider()
st.header("Step 4: AutoML Model Competition")
st.write("Ranked by **Macro F1-Score**, not accuracy -- accuracy is misleading on imbalanced failure data.")

if st.button("🚀 Run AutoML Training", type="primary"):
    with st.spinner("Training XGBoost, Random Forest, Gradient Boosting, and Extra Trees..."):
        results_df, trained_models, champion_name = cached_train_and_compare(
            X_train_scaled, X_test_scaled, y_train, y_test
        )
    st.session_state.update(results_df=results_df, trained_models=trained_models, champion_name=champion_name)
    st.success(f"Training complete -- Champion model: **{champion_name}**")

if "results_df" in st.session_state:
    results_df = st.session_state["results_df"]
    trained_models = st.session_state["trained_models"]
    champion_name = st.session_state["champion_name"]

    st.dataframe(results_df, use_container_width=True)
    metric_cols = st.columns(len(results_df))
    for i, row in results_df.iterrows():
        metric_cols[i].metric(row["Model"], f"{row['Macro F1-Score']:.3f}",
                               "🏆 Champion" if row["Model"] == champion_name else None)
    st.markdown(f"### 🏆 Champion Model: **{champion_name}**")

    champion_model = trained_models[champion_name]
    with st.expander("Champion model -- detailed classification report"):
        champion_preds = champion_model.predict(X_test_scaled)
        st.text(get_classification_report(y_test, champion_preds, class_names))
        cm = get_confusion_matrix(y_test, champion_preds, class_names)
        st.pyplot(plot_confusion_matrix_heatmap(cm, class_names))

    # ============================================================
    # STEP 5: TOP-2 RISK PREDICTIONS
    # ============================================================
    st.divider()
    st.header("Step 5: Top-2 Risk Predictions")

    top2_results = top_k_risk_predictions(champion_model, X_test_scaled, class_names, k=2)

    risk_table = X_test.reset_index(drop=True).copy()
    risk_table["Actual"] = [class_names[i] for i in y_test.reset_index(drop=True)]
    risk_table["Primary Risk (Confidence %)"] = [f"{c} ({p:.1f}%)" for c, p in (r[0] for r in top2_results)]
    risk_table["Secondary Risk (Confidence %)"] = [f"{c} ({p:.1f}%)" for c, p in (r[1] for r in top2_results)]

    st.dataframe(risk_table, use_container_width=True)
    csv_out = risk_table.to_csv(index=False).encode("utf-8")
    st.download_button("⬇️ Download Top-2 Risk Predictions as CSV", data=csv_out,
                        file_name="top2_risk_predictions.csv", mime="text/csv")
else:
    st.info("Click **Run AutoML Training** above to start the model competition.")
