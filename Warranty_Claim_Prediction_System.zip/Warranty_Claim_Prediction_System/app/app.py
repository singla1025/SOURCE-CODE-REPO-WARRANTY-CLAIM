"""
app/app.py
============
Streamlit deployment app for the AI4I 2020 warranty-claim failure
classifier. Thin by design -- all real logic lives in src/, this file
is just the UI layer that wires it together.

Run with:  streamlit run app/app.py   (from the project root)
"""

from pathlib import Path
import sys

# Allow `import src...` to work whether this is run from the project root
# or from inside app/ (Streamlit Cloud runs it from the repo root).
PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

import matplotlib.pyplot as plt
import seaborn as sns
import streamlit as st

from src.deployment.artifact_io import load_artifacts
from src.deployment.inference import predict_ai4i_failures
from src.preprocessing.clean_ai4i import CLASS_NAMES

st.set_page_config(page_title="Predictive Maintenance Failure Classifier", layout="wide")

CLASS_DESCRIPTIONS = {
    "Normal": "No failure detected",
    "TWF": "Tool Wear Failure",
    "HDF": "Heat Dissipation Failure",
    "PWF": "Power Failure",
    "OSF": "Overstrain Failure",
    "RNF": "Random Failure",
}

REQUIRED_RAW_COLUMNS = [
    "Type", "Air temperature [K]", "Process temperature [K]",
    "Rotational speed [rpm]", "Torque [Nm]", "Tool wear [min]",
]


@st.cache_resource
def get_artifacts():
    return load_artifacts()


try:
    bundle = get_artifacts()
except FileNotFoundError as e:
    st.error(str(e))
    st.stop()

model = bundle["model"]
scaler = bundle["scaler"]
label_encoder = bundle["label_encoder"]

st.title("🔧 Predictive Maintenance — Failure Type Classifier")
st.write(
    "Upload a CSV with the same sensor columns as the AI4I 2020 dataset and this app "
    "will classify each machine reading into one of six failure categories."
)

with st.expander("Expected columns in your CSV"):
    st.write(REQUIRED_RAW_COLUMNS)

uploaded_file = st.file_uploader("Upload your dataset (CSV)", type=["csv"])

if uploaded_file is not None:
    import pandas as pd
    raw_df = pd.read_csv(uploaded_file)

    st.subheader("Preview of uploaded data")
    st.dataframe(raw_df.head())

    try:
        result_df = predict_ai4i_failures(raw_df, model, scaler, label_encoder)
    except ValueError as e:
        st.error(str(e))
        st.stop()

    result_df["failure_description"] = result_df["predicted_failure_type"].map(CLASS_DESCRIPTIONS)

    st.subheader("Predictions")
    display_cols = list(raw_df.columns) + ["predicted_failure_type", "failure_description"]
    st.dataframe(result_df[display_cols])

    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Predicted Class Distribution")
        fig, ax = plt.subplots(figsize=(6, 4))
        sns.countplot(
            data=result_df, y="predicted_failure_type", order=CLASS_NAMES,
            hue="predicted_failure_type", palette="rocket", legend=False, ax=ax,
        )
        ax.set_xlabel("Count")
        ax.set_ylabel("")
        st.pyplot(fig)

    with col2:
        st.subheader("Failure Rate Summary")
        total = len(result_df)
        failure_count = int((result_df["predicted_failure_type"] != "Normal").sum())
        st.metric("Total Rows Scored", total)
        st.metric("Predicted Failures", failure_count)
        st.metric("Failure Rate", f"{failure_count / total * 100:.2f}%")

    csv_out = result_df.to_csv(index=False).encode("utf-8")
    st.download_button(
        "⬇️ Download Predictions as CSV",
        data=csv_out, file_name="predictions.csv", mime="text/csv",
    )
else:
    st.info("Upload a CSV file to get started.")
