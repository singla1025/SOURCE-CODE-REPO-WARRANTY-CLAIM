# Project Overview — Predictive Maintenance Warranty Claim Classifier

## Problem

Predict *which type* of failure (not just whether one occurred) is
driving a warranty claim, using machine sensor readings, so claims can
be triaged by likely root cause instead of treated as one undifferentiated
bucket.

Two deliverables share the same underlying `src/` codebase:

1. **A fixed, deployable classifier** for the AI4I 2020 Predictive
   Maintenance dataset specifically (`app/app.py`) — six classes:
   Normal, TWF, HDF, PWF, OSF, RNF.
2. **A dataset-agnostic AutoML dashboard** (`app/automl_app.py`) that
   can ingest other fault/failure datasets (Steel Plates Faults, Pump
   Sensor Data, Device Failure Classification, ...) and races four
   algorithms to find the best model for whatever was uploaded.

## Why two apps, one codebase

The fixed app is what you'd actually hand to a warranty-processing team —
stable schema, one trained model, fast and predictable. The AutoML
dashboard is an exploration/demo tool for *new* datasets where the schema
and failure modes aren't known in advance. Both import the same
`src/preprocessing`, `src/model`, `src/evaluation`, and `src/deployment`
modules rather than duplicating logic, so a bug fix in one (e.g. the
bracket-character sanitization fix for XGBoost) benefits both.

## Data flow

```
data/raw_data/ai4i2020.csv
        │
        ▼
src/data_collection/load_data.py        (read CSV)
        │
        ▼
src/preprocessing/clean_ai4i.py          (rename, build failure_type target, drop leakage)
   or
src/preprocessing/generic_cleaning.py    (dataset-agnostic version, used by AutoML app)
        │
        ▼
data/processed_data/ai4i2020_cleaned.csv (saved artifact of the above)
        │
        ▼
train/test split (stratified 80/20) + StandardScaler
        │
        ▼
src/model/train_model.py                 (single XGBoost, balanced sample weights)
   or
src/model/automl_trainer.py              (4-model competition, Macro F1 leaderboard)
        │
        ▼
src/evaluation/metrics.py + plots.py     (classification report, confusion matrix)
        │
        ▼
src/deployment/artifact_io.py            (bundle model + scaler + encoder -> .pkl)
        │
        ▼
models/trained_model/model_artifacts.pkl
        │
        ▼
app/app.py  (loads the bundle, serves predictions on uploaded CSVs)
```

## Key design decisions

- **Leakage prevention is structural, not manual.** `detect_aggregate_leakage`
  generically finds any binary column that's exactly the logical OR of
  others (like AI4I's `Machine failure`) and drops it — this isn't
  hardcoded to one dataset's column names.
- **Macro F1 over accuracy.** Every dataset this project targets is
  heavily imbalanced (failures are rare by definition). A model that
  always predicts "Normal" would score >95% accuracy and be useless;
  Macro F1 punishes that.
- **Sample weights over `scale_pos_weight`.** `scale_pos_weight` only
  works for binary classification. `compute_sample_weight("balanced", y)`
  generalizes to any number of classes and is applied identically across
  all 4 AutoML candidates for a fair comparison.
- **Train/serve skew is prevented by bundling artifacts.** The scaler and
  label encoder fitted during training are saved *with* the model, not
  separately, so the app can never accidentally re-fit them on new data.

## Known limitations

- Rare classes (e.g. AI4I's TWF: 18 rows, RNF: 46 rows out of 10,000)
  have inherently noisy recall — see `models/trained_model/evaluation_report.txt`.
  More data for those specific failure modes, not more model tuning, is
  the lever that would move this metric most.
- The AutoML dashboard's identifier/target/leakage detection is
  heuristic. The UI always shows its guesses in editable widgets before
  training starts, but unusual schemas may still need manual correction.
- Large datasets (e.g. Pump Sensor Data's 200k+ rows) are down-sampled to
  50,000 rows for AutoML training to stay responsive on free-tier hosting.
