"""
train_pipeline.py
====================
Glue script that runs the full AI4I 2020 pipeline end-to-end using the
modular src/ code, and writes real artifacts to disk:

  data/processed_data/ai4i2020_cleaned.csv   <- cleaned, leakage-free dataset
  models/trained_model/model_artifacts.pkl    <- model + scaler + label encoder
  models/trained_model/evaluation_report.txt  <- classification report

This is the script equivalent of running the training notebook end-to-end;
useful for CI, Docker builds, or anyone who'd rather not open Colab.

Usage:
    python train_pipeline.py
"""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))

from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split

from src.data_collection.load_data import load_csv
from src.preprocessing.clean_ai4i import (
    clean_ai4i_dataframe, FEATURE_COLUMNS, NUMERIC_COLUMNS, CLASS_NAMES,
)
from src.model.train_model import train_xgboost_classifier
from src.evaluation.metrics import get_classification_report, macro_f1
from src.deployment.artifact_io import save_artifacts

PROJECT_ROOT = Path(__file__).resolve().parent
PROCESSED_DATA_PATH = PROJECT_ROOT / "data" / "processed_data" / "ai4i2020_cleaned.csv"
EVAL_REPORT_PATH = PROJECT_ROOT / "models" / "trained_model" / "evaluation_report.txt"


def main():
    print("1/6  Loading raw data...")
    raw_df = load_csv("ai4i2020.csv")
    print(f"     {raw_df.shape[0]:,} rows x {raw_df.shape[1]} columns")

    print("2/6  Cleaning (rename, build failure_type target, drop leakage)...")
    df = clean_ai4i_dataframe(raw_df)
    PROCESSED_DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(PROCESSED_DATA_PATH, index=False)
    print(f"     Saved cleaned dataset -> {PROCESSED_DATA_PATH}")
    print("     Class distribution:\n", df["failure_type"].value_counts().sort_index().to_string())

    print("3/6  Encoding categorical 'type' column...")
    label_encoder = LabelEncoder()
    df["type_encoded"] = label_encoder.fit_transform(df["type"])

    print("4/6  Splitting (80/20 stratified) and scaling...")
    X = df[FEATURE_COLUMNS]
    y = df["failure_type"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, stratify=y, random_state=42
    )
    scaler = StandardScaler()
    X_train_scaled, X_test_scaled = X_train.copy(), X_test.copy()
    X_train_scaled[NUMERIC_COLUMNS] = scaler.fit_transform(X_train[NUMERIC_COLUMNS])
    X_test_scaled[NUMERIC_COLUMNS] = scaler.transform(X_test[NUMERIC_COLUMNS])

    print("5/6  Training XGBoost (balanced sample weights)...")
    model = train_xgboost_classifier(X_train_scaled, y_train, n_classes=len(CLASS_NAMES))

    preds = model.predict(X_test_scaled)
    report = get_classification_report(y_test, preds, CLASS_NAMES)
    f1 = macro_f1(y_test, preds)
    print(f"     Macro F1-Score on held-out test set: {f1:.4f}")
    print(report)

    EVAL_REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
    EVAL_REPORT_PATH.write_text(
        f"Macro F1-Score: {f1:.4f}\n\n{report}", encoding="utf-8"
    )
    print(f"     Saved evaluation report -> {EVAL_REPORT_PATH}")

    print("6/6  Saving model artifacts...")
    artifact_path = save_artifacts(
        model=model, scaler=scaler, label_encoder=label_encoder,
        feature_cols=FEATURE_COLUMNS, numeric_cols=NUMERIC_COLUMNS,
        class_names=CLASS_NAMES,
    )
    print(f"     Saved -> {artifact_path}")
    print("\nDone. app/app.py will load this file automatically.")


if __name__ == "__main__":
    main()
