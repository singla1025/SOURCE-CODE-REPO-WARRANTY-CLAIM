"""tests/test_deployment.py -- artifact save/load roundtrip + inference logic."""

import numpy as np
import pandas as pd
import pytest
from sklearn.preprocessing import LabelEncoder, StandardScaler

from src.deployment.artifact_io import save_artifacts, load_artifacts
from src.deployment.inference import predict_ai4i_failures, top_k_risk_predictions
from src.model.train_model import train_xgboost_classifier
from src.preprocessing.clean_ai4i import clean_ai4i_dataframe, FEATURE_COLUMNS, NUMERIC_COLUMNS, CLASS_NAMES


@pytest.fixture
def trained_bundle(tmp_path, ai4i_style_df):
    df = clean_ai4i_dataframe(ai4i_style_df)
    label_encoder = LabelEncoder()
    df["type_encoded"] = label_encoder.fit_transform(df["type"])

    X, y = df[FEATURE_COLUMNS], df["failure_type"]
    scaler = StandardScaler()
    X_scaled = X.copy()
    X_scaled[NUMERIC_COLUMNS] = scaler.fit_transform(X[NUMERIC_COLUMNS])

    model = train_xgboost_classifier(X_scaled, y, n_classes=len(CLASS_NAMES), n_estimators=20)

    path = tmp_path / "model_artifacts.pkl"
    save_artifacts(model, scaler, label_encoder, FEATURE_COLUMNS, NUMERIC_COLUMNS, CLASS_NAMES, path=path)
    return path, model, scaler, label_encoder


def test_save_and_load_artifacts_roundtrip(trained_bundle):
    path, model, scaler, label_encoder = trained_bundle
    bundle = load_artifacts(path)
    assert set(bundle.keys()) >= {"model", "scaler", "label_encoder", "feature_cols", "numeric_cols", "class_names"}
    assert bundle["class_names"] == CLASS_NAMES


def test_load_artifacts_missing_file_raises_helpful_error(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_artifacts(tmp_path / "does_not_exist.pkl")


def test_predict_ai4i_failures_end_to_end(trained_bundle, ai4i_style_df):
    path, model, scaler, label_encoder = trained_bundle
    result = predict_ai4i_failures(ai4i_style_df, model, scaler, label_encoder)
    assert "predicted_failure_type" in result.columns
    assert set(result["predicted_failure_type"].unique()) <= set(CLASS_NAMES)
    assert len(result) == len(ai4i_style_df)


def test_predict_ai4i_failures_missing_columns_raises_value_error(trained_bundle):
    path, model, scaler, label_encoder = trained_bundle
    bad_df = pd.DataFrame({"Type": ["L", "M"]})
    with pytest.raises(ValueError):
        predict_ai4i_failures(bad_df, model, scaler, label_encoder)


def test_top_k_risk_predictions_shape_and_ordering(trained_bundle, ai4i_style_df):
    path, model, scaler, label_encoder = trained_bundle
    df = clean_ai4i_dataframe(ai4i_style_df)
    df["type_encoded"] = label_encoder.transform(df["type"])
    X = df[FEATURE_COLUMNS].copy()
    X[NUMERIC_COLUMNS] = scaler.transform(X[NUMERIC_COLUMNS])

    results = top_k_risk_predictions(model, X, CLASS_NAMES, k=2)
    assert len(results) == len(X)
    for row in results:
        assert len(row) == 2
        # primary confidence must be >= secondary confidence (argsort descending)
        assert row[0][1] >= row[1][1]
