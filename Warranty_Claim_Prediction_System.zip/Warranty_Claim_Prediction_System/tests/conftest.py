"""Shared pytest fixtures: synthetic datasets mimicking real-world schemas."""

import sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


@pytest.fixture
def ai4i_style_df():
    """Mimics AI4I 2020: 5 binary flags + a redundant OR-aggregate column."""
    rng = np.random.RandomState(0)
    n = 500
    twf = rng.binomial(1, 0.02, n)
    hdf = rng.binomial(1, 0.02, n)
    pwf = rng.binomial(1, 0.02, n)
    osf = rng.binomial(1, 0.02, n)
    rnf = rng.binomial(1, 0.01, n)
    machine_failure = ((twf + hdf + pwf + osf + rnf) > 0).astype(int)
    return pd.DataFrame({
        "UDI": np.arange(1, n + 1),
        "Product ID": [f"M{i}" for i in range(n)],
        "Type": rng.choice(["L", "M", "H"], n),
        "Air temperature [K]": rng.normal(300, 2, n),
        "Process temperature [K]": rng.normal(310, 2, n),
        "Rotational speed [rpm]": rng.normal(1500, 100, n),
        "Torque [Nm]": rng.normal(40, 5, n),
        "Tool wear [min]": rng.randint(0, 250, n),
        "TWF": twf, "HDF": hdf, "PWF": pwf, "OSF": osf, "RNF": rnf,
        "Machine failure": machine_failure,
    })


@pytest.fixture
def steel_plates_style_df():
    """Mimics Steel Plates Faults: 7 mutually exclusive binary flags, no aggregate."""
    rng = np.random.RandomState(1)
    n = 300
    fault_names = ["Pastry", "Z_Scratch", "K_Scatch", "Stains", "Dirtiness", "Bumps", "Other_Faults"]
    labels = rng.randint(0, len(fault_names), n)
    faults = {name: (labels == i).astype(int) for i, name in enumerate(fault_names)}
    df = pd.DataFrame(faults)
    df["X_Minimum"] = rng.randint(0, 1000, n)
    df["Length_of_Conveyer"] = rng.normal(1500, 100, n)
    return df


@pytest.fixture
def single_target_style_df():
    """Mimics Pump Sensor Data: one categorical target column, no binary flags."""
    rng = np.random.RandomState(2)
    n = 400
    return pd.DataFrame({
        "sensor_00": rng.normal(50, 5, n),
        "sensor_01": rng.normal(20, 3, n),
        "machine_status": rng.choice(["NORMAL", "BROKEN", "RECOVERING"], n, p=[0.9, 0.05, 0.05]),
    })
