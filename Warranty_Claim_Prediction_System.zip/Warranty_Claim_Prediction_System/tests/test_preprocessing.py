"""
tests/test_preprocessing.py
==============================
Validates the dataset-agnostic detection logic against the 3 dataset
shapes the AutoML dashboard is meant to handle, plus the AI4I-specific
cleaning pipeline.
"""

from src.preprocessing.generic_cleaning import (
    detect_identifier_columns, detect_binary_columns,
    detect_aggregate_leakage, sanitize_column_name, build_features,
)
from src.preprocessing.clean_ai4i import clean_ai4i_dataframe, FAILURE_PRIORITY


def test_identifier_detection_catches_udi_and_product_id(ai4i_style_df):
    ids = detect_identifier_columns(ai4i_style_df)
    assert "UDI" in ids
    assert "Product ID" in ids  # has a space, not an underscore -- regression test


def test_aggregate_leakage_detected_for_ai4i_machine_failure(ai4i_style_df):
    binary_cols = detect_binary_columns(ai4i_style_df)
    aggregates = detect_aggregate_leakage(ai4i_style_df, binary_cols)
    assert "Machine failure" in aggregates
    usable = [c for c in binary_cols if c not in aggregates]
    assert set(usable) == {"TWF", "HDF", "PWF", "OSF", "RNF"}


def test_no_false_positive_aggregate_on_mutually_exclusive_flags(steel_plates_style_df):
    binary_cols = detect_binary_columns(steel_plates_style_df)
    aggregates = detect_aggregate_leakage(steel_plates_style_df, binary_cols)
    assert aggregates == []
    assert len(binary_cols) == 7


def test_single_target_dataset_has_no_binary_indicator_columns(single_target_style_df):
    binary_cols = detect_binary_columns(single_target_style_df)
    assert binary_cols == []


def test_sanitize_column_name_strips_units_and_brackets():
    assert sanitize_column_name("Air temperature [K]") == "air_temperature"
    assert sanitize_column_name("Torque [Nm]") == "torque"
    assert "[" not in sanitize_column_name("Rotational speed [rpm]")
    assert "]" not in sanitize_column_name("Rotational speed [rpm]")


def test_build_features_multi_binary_path(ai4i_style_df):
    cols_to_drop = ["UDI", "Product ID", "Machine failure"]
    binary_cols = ["TWF", "HDF", "PWF", "OSF", "RNF"]
    df, feature_cols, numeric_cols, categorical_cols, class_names = build_features(
        ai4i_style_df, tuple(cols_to_drop), "multi_binary", None, tuple(binary_cols)
    )
    assert "target" in df.columns
    assert class_names[0] == "Normal"
    assert set(class_names[1:]) == {"TWF", "HDF", "PWF", "OSF", "RNF"}
    # no leakage columns survive into features
    assert not any(c in feature_cols for c in ["udi", "product_id", "twf", "hdf", "pwf", "osf", "rnf"])
    # no bracket characters survive (the XGBoost-crashing bug)
    assert all("[" not in c and "]" not in c for c in feature_cols)


def test_build_features_single_target_path(single_target_style_df):
    df, feature_cols, numeric_cols, categorical_cols, class_names = build_features(
        single_target_style_df, tuple(), "single", "machine_status", tuple()
    )
    assert "target" in df.columns
    assert set(class_names) == {"NORMAL", "BROKEN", "RECOVERING"}
    assert "machine_status" not in feature_cols


def test_clean_ai4i_dataframe_drops_leakage_and_builds_failure_type(ai4i_style_df):
    df = clean_ai4i_dataframe(ai4i_style_df)
    assert "failure_type" in df.columns
    for leaky_col in ["udi", "product_id", "machine_failure"] + FAILURE_PRIORITY:
        assert leaky_col not in df.columns
    assert df["failure_type"].between(0, 5).all()
