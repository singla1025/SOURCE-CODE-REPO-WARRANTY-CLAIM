"""
tests/test_model.py
======================
Smoke tests for the training modules -- not aiming for high accuracy on
tiny synthetic data, just confirming the training/prediction contracts
hold (correct shapes, no crashes, sample weighting actually applied).
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from src.model.train_model import compute_balanced_sample_weights, train_xgboost_classifier
from src.model.automl_trainer import train_and_compare, build_candidate_models


def _make_synthetic_classification_data(n=300, n_classes=4, n_features=5, seed=0):
    rng = np.random.RandomState(seed)
    X = pd.DataFrame(rng.normal(size=(n, n_features)), columns=[f"f{i}" for i in range(n_features)])
    y = pd.Series(rng.randint(0, n_classes, n))
    return train_test_split(X, y, test_size=0.25, random_state=seed)


def test_compute_balanced_sample_weights_inversely_proportional_to_frequency():
    y = pd.Series([0] * 90 + [1] * 10)
    weights = compute_balanced_sample_weights(y)
    assert len(weights) == len(y)
    assert weights[y == 1].mean() > weights[y == 0].mean()


def test_train_xgboost_classifier_fits_and_predicts():
    X_train, X_test, y_train, y_test = _make_synthetic_classification_data(n_classes=3)
    model = train_xgboost_classifier(X_train, y_train, n_classes=3, n_estimators=20)
    preds = model.predict(X_test)
    assert len(preds) == len(X_test)
    assert set(preds.tolist()) <= {0, 1, 2}


def test_build_candidate_models_returns_four_algorithms():
    candidates = build_candidate_models(n_classes=5)
    assert set(candidates.keys()) == {"XGBoost", "Random Forest", "Gradient Boosting", "Extra Trees"}


def test_train_and_compare_returns_leaderboard_and_champion():
    X_train, X_test, y_train, y_test = _make_synthetic_classification_data(n_classes=3)
    results_df, trained_models, champion_name = train_and_compare(X_train, X_test, y_train, y_test)

    assert len(results_df) == 4
    assert {"Model", "Macro F1-Score", "Training Time (s)"} <= set(results_df.columns)
    assert champion_name in trained_models
    # leaderboard must actually be sorted best-first
    scores = results_df["Macro F1-Score"].tolist()
    assert scores == sorted(scores, reverse=True)
    # champion model must support predict_proba (needed for Top-K risk inference)
    champion = trained_models[champion_name]
    probs = champion.predict_proba(X_test)
    assert probs.shape[0] == len(X_test)
