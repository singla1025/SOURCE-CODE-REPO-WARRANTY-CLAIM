"""tests/test_evaluation.py -- metric and plotting helper contracts."""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")  # no display available in CI/sandbox

from src.evaluation.metrics import get_classification_report, get_confusion_matrix, macro_f1
from src.evaluation.plots import plot_confusion_matrix_heatmap, plot_correlation_heatmap


def test_macro_f1_perfect_predictions_is_one():
    y_true = [0, 1, 2, 0, 1, 2]
    y_pred = [0, 1, 2, 0, 1, 2]
    assert macro_f1(y_true, y_pred) == 1.0


def test_confusion_matrix_shape_matches_class_count():
    class_names = ["Normal", "TWF", "HDF"]
    y_true = [0, 0, 1, 2, 2]
    y_pred = [0, 1, 1, 2, 0]
    cm = get_confusion_matrix(y_true, y_pred, class_names)
    assert cm.shape == (3, 3)
    assert cm.sum() == len(y_true)


def test_classification_report_contains_all_class_names():
    class_names = ["Normal", "TWF", "HDF"]
    y_true = [0, 0, 1, 2, 2]
    y_pred = [0, 1, 1, 2, 0]
    report = get_classification_report(y_true, y_pred, class_names)
    for name in class_names:
        assert name in report


def test_plot_confusion_matrix_heatmap_returns_figure():
    cm = np.array([[5, 1], [0, 4]])
    fig = plot_confusion_matrix_heatmap(cm, ["Normal", "Fault"])
    assert fig is not None
    assert len(fig.axes) >= 1


def test_plot_correlation_heatmap_returns_figure_and_corr_matrix():
    df = pd.DataFrame({
        "a": np.random.normal(size=50),
        "b": np.random.normal(size=50),
        "target": np.random.randint(0, 2, 50),
    })
    fig, corr = plot_correlation_heatmap(df, numeric_cols=["a", "b"])
    assert fig is not None
    assert "target" in corr.columns
