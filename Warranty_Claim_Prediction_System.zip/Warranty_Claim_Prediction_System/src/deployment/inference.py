"""
src/deployment/inference.py
==============================
Inference-time logic shared by app/app.py (single champion model) and
app/automl_app.py (Top-K risk predictions). Kept separate from both apps
so the same prediction logic is testable without spinning up Streamlit.
"""

import numpy as np
import pandas as pd

from src.preprocessing.clean_ai4i import RENAME_MAP, FEATURE_COLUMNS, NUMERIC_COLUMNS, CLASS_NAMES


def predict_ai4i_failures(raw_df: pd.DataFrame, model, scaler, label_encoder) -> pd.DataFrame:
    """
    Apply the exact same cleaning/encoding/scaling used at training time to
    a freshly uploaded AI4I-schema CSV, then predict failure_type for every row.
    """
    df = raw_df.rename(columns=RENAME_MAP)

    missing = [c for c in ["type", "air_temperature", "process_temperature",
                            "rotational_speed", "torque", "tool_wear"] if c not in df.columns]
    if missing:
        raise ValueError(f"Uploaded file is missing required columns: {missing}")

    df["type_encoded"] = label_encoder.transform(df["type"])

    X = df[FEATURE_COLUMNS].copy()
    X[NUMERIC_COLUMNS] = scaler.transform(X[NUMERIC_COLUMNS])

    preds = model.predict(X)
    df["predicted_failure_type"] = [CLASS_NAMES[p] for p in preds]
    return df


def top_k_risk_predictions(model, X, class_names, k=2):
    """
    Use predict_proba + np.argsort to surface the top-K most likely classes
    per row with confidence percentages, rather than a single hard label.

    Returns
    -------
    list[list[tuple[str, float]]] -- for each row, K (class_name, confidence_pct) pairs,
    ordered from most to least likely.
    """
    probs = model.predict_proba(X)
    ranked_idx = np.argsort(probs, axis=1)[:, ::-1][:, :k]

    results = []
    for row_idx, class_idx_row in enumerate(ranked_idx):
        row_result = [
            (class_names[class_idx], probs[row_idx, class_idx] * 100.0)
            for class_idx in class_idx_row
        ]
        results.append(row_result)
    return results
