"""
src/deployment/artifact_io.py
================================
Save/load the bundle of objects a deployed model needs together:
the fitted estimator, the fitted scaler, the fitted label encoder, and
the column lists. Saving these separately is a common source of
train/serve skew bugs -- bundling them in one file removes that risk.
"""

from pathlib import Path
import joblib

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_ARTIFACT_PATH = PROJECT_ROOT / "models" / "trained_model" / "model_artifacts.pkl"


def save_artifacts(model, scaler, label_encoder, feature_cols, numeric_cols,
                    class_names, path=DEFAULT_ARTIFACT_PATH):
    bundle = {
        "model": model,
        "scaler": scaler,
        "label_encoder": label_encoder,
        "feature_cols": feature_cols,
        "numeric_cols": numeric_cols,
        "class_names": class_names,
    }
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(bundle, path)
    return path


def load_artifacts(path=DEFAULT_ARTIFACT_PATH):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"No trained model found at {path}. Run notebooks/"
            "AI4I_2020_Predictive_Maintenance_MultiClass.ipynb (Section 6) "
            "or scripts that call src.deployment.artifact_io.save_artifacts() first."
        )
    return joblib.load(path)
