"""
src/evaluation/metrics.py
============================
Metric helpers shared by the notebook, the apps, and tests/test_evaluation.py.
"""

from sklearn.metrics import classification_report, confusion_matrix, f1_score


def get_classification_report(y_true, y_pred, class_names) -> str:
    """Text classification report using human-readable class names."""
    return classification_report(
        y_true, y_pred,
        labels=list(range(len(class_names))),
        target_names=class_names,
        zero_division=0,
    )


def get_confusion_matrix(y_true, y_pred, class_names):
    """Confusion matrix as a numpy array, ordered to match class_names."""
    return confusion_matrix(y_true, y_pred, labels=list(range(len(class_names))))


def macro_f1(y_true, y_pred) -> float:
    """The metric that matters on imbalanced failure data -- not accuracy."""
    return f1_score(y_true, y_pred, average="macro", zero_division=0)
