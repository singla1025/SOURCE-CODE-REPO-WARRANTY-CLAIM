"""
src/evaluation/plots.py
==========================
Matplotlib/Seaborn figure builders shared across the notebook and both
Streamlit apps. Every function RETURNS a Figure rather than calling
plt.show(), so callers (notebook cells, st.pyplot(), or tests checking
fig.axes) can each decide what to do with it.
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


def plot_confusion_matrix_heatmap(cm, class_names, title="Confusion Matrix"):
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.heatmap(
        cm, annot=True, fmt="d", cmap="rocket_r",
        xticklabels=class_names, yticklabels=class_names,
        cbar_kws={"label": "Count"}, linewidths=0.5, linecolor="white", ax=ax,
    )
    ax.set_title(title, fontweight="bold")
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    fig.tight_layout()
    return fig


def plot_correlation_heatmap(df, numeric_cols, target_col="target"):
    cols = numeric_cols + [target_col] if target_col in df.columns else numeric_cols
    corr = df[cols].corr()
    fig, ax = plt.subplots(figsize=(7, 6))
    sns.heatmap(corr, cmap="coolwarm", center=0, ax=ax)
    ax.set_title("Correlation Heatmap")
    fig.tight_layout()
    return fig, corr


def plot_class_separation_scatter(df, x_col, y_col, target_col, class_names):
    fig, ax = plt.subplots(figsize=(7, 6))
    sns.scatterplot(data=df, x=x_col, y=y_col, hue=target_col, palette="tab10", alpha=0.6, s=30, ax=ax)
    handles, _ = ax.get_legend_handles_labels()
    if handles:
        ax.legend(handles, class_names[: len(handles)], title="Class", bbox_to_anchor=(1.02, 1), loc="upper left")
    ax.set_title(f"Class Separation: {x_col} vs {y_col}")
    fig.tight_layout()
    return fig


def plot_class_distribution(df, target_col, class_names):
    fig, ax = plt.subplots(figsize=(7, 5))
    sns.countplot(x=target_col, data=df, hue=target_col, palette="rocket", legend=False, ax=ax)
    ax.set_xticks(range(len(class_names)))
    ax.set_xticklabels(class_names, rotation=30, ha="right")
    ax.set_xlabel("")
    ax.set_title("Target Class Distribution")
    fig.tight_layout()
    return fig


def plot_feature_by_class_boxplot(df, feature_col, target_col, class_names):
    fig, ax = plt.subplots(figsize=(7, 5))
    sns.boxplot(x=target_col, y=feature_col, data=df, hue=target_col, palette="mako", legend=False, ax=ax)
    ax.set_xticks(range(len(class_names)))
    ax.set_xticklabels(class_names, rotation=30, ha="right")
    ax.set_xlabel("")
    ax.set_title(f"{feature_col} by Class")
    fig.tight_layout()
    return fig
