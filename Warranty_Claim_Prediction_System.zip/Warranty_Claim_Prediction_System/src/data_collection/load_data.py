"""
src/data_collection/load_data.py
=================================
Single responsibility: get raw tabular data into a pandas DataFrame.

This module is intentionally thin. Today it just reads CSVs from
data/raw_data/, but it's the seam where future ingestion sources
(a sensor API, a database query, a Kaggle API pull) would plug in
without touching preprocessing, modeling, or app code.
"""

from pathlib import Path
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[2]
RAW_DATA_DIR = PROJECT_ROOT / "data" / "raw_data"


def load_csv(filename: str, raw_data_dir: Path = RAW_DATA_DIR) -> pd.DataFrame:
    """
    Load a CSV file from the raw data directory.

    Parameters
    ----------
    filename : str
        Name of the CSV file, e.g. "ai4i2020.csv".
    raw_data_dir : Path
        Directory to look in. Defaults to data/raw_data/ at the project root.

    Returns
    -------
    pd.DataFrame
    """
    path = Path(raw_data_dir) / filename
    if not path.exists():
        raise FileNotFoundError(
            f"Could not find '{filename}' in {raw_data_dir}. "
            "Place the raw dataset there before running the pipeline."
        )
    return pd.read_csv(path)


def load_uploaded_csv(file_like) -> pd.DataFrame:
    """
    Load a CSV from an in-memory file object (e.g. Streamlit's file_uploader,
    or a Flask request.files object). Kept separate from load_csv() so the
    deployment layer never needs to know about the data/ folder structure.
    """
    return pd.read_csv(file_like)
