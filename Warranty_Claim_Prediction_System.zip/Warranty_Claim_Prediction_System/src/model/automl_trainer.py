"""
src/model/automl_trainer.py
==============================
The AutoML competition engine used by app/automl_app.py: races XGBoost,
Random Forest, Gradient Boosting, and Extra Trees against each other and
crowns a Champion Model by Macro F1-Score (not accuracy -- failure
datasets are almost always heavily imbalanced).

Kept Streamlit-free on purpose so it's directly unit-testable
(see tests/test_model.py) and reusable from a future batch/CLI pipeline.
"""

import time
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, ExtraTreesClassifier
from sklearn.metrics import f1_score
from sklearn.utils.class_weight import compute_sample_weight
from xgboost import XGBClassifier


def build_candidate_models(n_classes: int) -> dict:
    """The 4 algorithms entered into the competition."""
    return {
        "XGBoost": XGBClassifier(
            n_estimators=200, max_depth=6, learning_rate=0.1,
            eval_metric="mlogloss" if n_classes > 2 else "logloss",
            random_state=42, n_jobs=-1,
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=200, max_depth=None, random_state=42, n_jobs=-1,
        ),
        "Gradient Boosting": GradientBoostingClassifier(
            n_estimators=150, max_depth=3, learning_rate=0.1, random_state=42,
        ),
        "Extra Trees": ExtraTreesClassifier(
            n_estimators=200, random_state=42, n_jobs=-1,
        ),
    }


def train_and_compare(X_train, X_test, y_train, y_test):
    """
    Train all 4 candidates, score each by Macro F1 on the held-out test set,
    and return a leaderboard plus the fitted model objects.

    Returns
    -------
    results_df : pd.DataFrame with columns [Model, Macro F1-Score, Training Time (s)]
    trained_models : dict[str, fitted estimator]
    champion_name : str -- the highest Macro-F1 model
    """
    sample_weights = compute_sample_weight(class_weight="balanced", y=y_train)
    n_classes = len(np.unique(y_train))
    candidates = build_candidate_models(n_classes)

    results, trained_models = [], {}
    for name, model in candidates.items():
        start = time.time()
        model.fit(X_train, y_train, sample_weight=sample_weights)
        elapsed = time.time() - start

        preds = model.predict(X_test)
        macro_f1 = f1_score(y_test, preds, average="macro", zero_division=0)

        results.append({
            "Model": name,
            "Macro F1-Score": round(macro_f1, 4),
            "Training Time (s)": round(elapsed, 2),
        })
        trained_models[name] = model

    results_df = pd.DataFrame(results).sort_values("Macro F1-Score", ascending=False).reset_index(drop=True)
    champion_name = results_df.iloc[0]["Model"]
    return results_df, trained_models, champion_name
