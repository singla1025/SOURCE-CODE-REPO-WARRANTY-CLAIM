"""
src/model/train_model.py
==========================
Single-model training for the AI4I 2020 warranty-claim pipeline:
XGBoost multi-class classifier, balanced via sample weights (not
scale_pos_weight, which is binary-only).
"""

from sklearn.utils.class_weight import compute_sample_weight
from xgboost import XGBClassifier


def compute_balanced_sample_weights(y_train):
    """Per-row weights inversely proportional to class frequency."""
    return compute_sample_weight(class_weight="balanced", y=y_train)


def train_xgboost_classifier(X_train, y_train, n_classes: int, **xgb_kwargs):
    """
    Train an XGBoost multi-class classifier with balanced sample weights.

    Parameters
    ----------
    X_train, y_train : training data
    n_classes : int
        Number of target classes (e.g. 6 for AI4I's Normal/TWF/HDF/PWF/OSF/RNF).
    xgb_kwargs : dict
        Optional overrides for XGBClassifier hyperparameters.
    """
    defaults = dict(
        objective="multi:softmax",
        num_class=n_classes,
        eval_metric="mlogloss",
        n_estimators=300,
        max_depth=6,
        learning_rate=0.1,
        subsample=0.9,
        colsample_bytree=0.9,
        random_state=42,
        n_jobs=-1,
    )
    defaults.update(xgb_kwargs)

    model = XGBClassifier(**defaults)
    sample_weights = compute_balanced_sample_weights(y_train)
    model.fit(X_train, y_train, sample_weight=sample_weights)
    return model
