"""
src/preprocessing/clean_ai4i.py
=================================
Deterministic cleaning pipeline specific to the AI4I 2020 Predictive
Maintenance dataset. This is the same logic used in
notebooks/AI4I_2020_Predictive_Maintenance_MultiClass.ipynb, extracted
into importable functions so app/app.py and tests/ don't duplicate it.
"""

import pandas as pd

RENAME_MAP = {
    "UDI": "udi",
    "Product ID": "product_id",
    "Type": "type",
    "Air temperature [K]": "air_temperature",
    "Process temperature [K]": "process_temperature",
    "Rotational speed [rpm]": "rotational_speed",
    "Torque [Nm]": "torque",
    "Tool wear [min]": "tool_wear",
    "Machine failure": "machine_failure",
    "TWF": "twf",
    "HDF": "hdf",
    "PWF": "pwf",
    "OSF": "osf",
    "RNF": "rnf",
}

# Priority order used when two failure flags overlap on the same row
# (24 rows in the standard AI4I 2020 release). Listed lowest -> highest;
# later entries overwrite earlier ones, so the most mechanistically
# specific failure mode wins.
FAILURE_PRIORITY = ["rnf", "osf", "pwf", "hdf", "twf"]
CLASS_NAMES = ["Normal", "TWF", "HDF", "PWF", "OSF", "RNF"]

FEATURE_COLUMNS = [
    "type_encoded", "air_temperature", "process_temperature",
    "rotational_speed", "torque", "tool_wear",
]
NUMERIC_COLUMNS = [
    "air_temperature", "process_temperature", "rotational_speed", "torque", "tool_wear",
]


def rename_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Snake_case the raw AI4I headers and strip unit suffixes like '[K]'."""
    return df.rename(columns=RENAME_MAP)


def build_failure_type_target(df: pd.DataFrame) -> pd.DataFrame:
    """
    Collapse the 5 binary failure flags into a single `failure_type` column
    (0=Normal ... 5=RNF), then drop the now-redundant binary flags and the
    `machine_failure` aggregate column to prevent data leakage.
    """
    df = df.copy()
    df["failure_type"] = 0
    for priority, col in enumerate(FAILURE_PRIORITY, start=1):
        df.loc[df[col] == 1, "failure_type"] = priority

    drop_cols = ["udi", "product_id"] + FAILURE_PRIORITY + ["machine_failure"]
    return df.drop(columns=[c for c in drop_cols if c in df.columns])


def clean_ai4i_dataframe(raw_df: pd.DataFrame) -> pd.DataFrame:
    """End-to-end clean: rename -> build target -> drop leakage/noise columns."""
    df = rename_columns(raw_df)
    df = build_failure_type_target(df)
    return df
