"""
src/preprocessing/generic_cleaning.py
========================================
Dataset-agnostic cleaning/detection logic used by the AutoML dashboard
(app/automl_app.py). Works across AI4I 2020, Steel Plates Faults, Pump
Sensor Data, Device Failure Classification, and similar fault datasets,
without hardcoding any single schema.

Validated against three dataset shapes (see tests/test_preprocessing.py):
  - multiple binary flags + a redundant OR-aggregate column (AI4I 2020)
  - multiple binary flags, no aggregate column (Steel Plates Faults)
  - a single categorical/binary target column (Pump Sensor Data, Device Failure)
"""

import re
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder


def sanitize_column_name(name: str) -> str:
    """
    Strip units like '[K]' / '[rpm]' and any non-alphanumeric characters.
    XGBoost specifically REJECTS feature names containing '[', ']', or '<',
    so raw Kaggle headers (e.g. 'Air temperature [K]') must be cleaned
    before they ever reach a model -- not just for cosmetics.
    """
    name = re.sub(r"\[.*?\]", "", str(name))
    name = re.sub(r"[^0-9a-zA-Z]+", "_", name)
    name = re.sub(r"_+", "_", name).strip("_").lower()
    return name or "col"


def detect_identifier_columns(df: pd.DataFrame) -> list:
    """Flag columns that look like row identifiers, not features."""
    n = len(df)
    candidates = []
    name_patterns = {"id", "index", "udi", "unnamed:_0"}
    for col in df.columns:
        name = col.lower().strip().replace(" ", "_").replace("-", "_")
        if name in name_patterns or name.endswith("_id") or name.startswith("id_") or "unnamed" in name:
            candidates.append(col)
            continue
        if df[col].nunique(dropna=True) == n:
            if df[col].dtype == object:
                candidates.append(col)
            elif pd.api.types.is_integer_dtype(df[col]):
                sorted_vals = df[col].dropna().sort_values().reset_index(drop=True)
                if len(sorted_vals) > 1:
                    start = sorted_vals.iloc[0]
                    if (sorted_vals == np.arange(start, start + len(sorted_vals))).all():
                        candidates.append(col)
    return candidates


def detect_binary_columns(df: pd.DataFrame, exclude=()) -> list:
    """Columns whose only non-null values are 0/1 -- candidate failure-mode flags."""
    binary_cols = []
    for col in df.columns:
        if col in exclude:
            continue
        vals = df[col].dropna().unique()
        if len(vals) == 2:
            try:
                if set(pd.Series(vals).astype(float)) <= {0.0, 1.0}:
                    binary_cols.append(col)
            except (ValueError, TypeError):
                continue
    return binary_cols


def detect_aggregate_leakage(df: pd.DataFrame, binary_cols: list) -> list:
    """
    A column like 'machine_failure' is often EXACTLY the logical OR of several
    specific failure flags (TWF, HDF, PWF...). That makes it pure leakage if
    kept as a feature -- find and flag it generically, without hardcoding names.
    """
    aggregates = []
    for cand in binary_cols:
        rest = [c for c in binary_cols if c != cand]
        if len(rest) >= 2:
            agg = (df[rest].fillna(0).sum(axis=1) > 0).astype(int)
            cand_vals = df[cand].fillna(0).astype(int).reset_index(drop=True)
            if (cand_vals == agg.reset_index(drop=True)).all():
                aggregates.append(cand)
    return aggregates


def guess_target_column(df: pd.DataFrame, exclude=()) -> str:
    """Best-effort guess at the label column by common naming conventions."""
    priority_keywords = [
        "failure_type", "target", "label", "class", "fault",
        "status", "failure", "outcome", "result", "defect",
    ]
    available = [c for c in df.columns if c not in exclude]
    lower_map = {c.lower(): c for c in available}
    for keyword in priority_keywords:
        for lower_name, original in lower_map.items():
            if keyword == lower_name or keyword in lower_name:
                return original
    return available[-1] if available else None


def build_features(raw_df, cols_to_drop, target_mode, target_col, binary_indicator_cols):
    """
    Deterministic cleaning + encoding pipeline shared by the AutoML app and
    its tests. Pure pandas/sklearn -- no Streamlit dependency, so it can be
    unit-tested in isolation.

    Returns
    -------
    df, feature_cols, numeric_cols, categorical_cols, class_names
    """
    df = raw_df.drop(columns=list(cols_to_drop), errors="ignore").copy()

    # Keep original-cased names for display (e.g. 'TWF') before sanitizing
    # the actual column names for model compatibility.
    original_label_lookup = {col: col for col in binary_indicator_cols}

    rename_map, seen = {}, {}
    for col in df.columns:
        clean = sanitize_column_name(col)
        if clean in seen:
            seen[clean] += 1
            clean = f"{clean}_{seen[clean]}"
        else:
            seen[clean] = 0
        rename_map[col] = clean
    df = df.rename(columns=rename_map)
    original_label_lookup = {rename_map.get(k, k): v for k, v in original_label_lookup.items()}
    binary_indicator_cols = [rename_map.get(c, c) for c in binary_indicator_cols]
    if target_mode == "single":
        target_col = rename_map.get(target_col, target_col)

    if target_mode == "multi_binary":
        ordered_cols = sorted(binary_indicator_cols, key=lambda c: df[c].sum(), reverse=True)
        class_names = ["Normal"] + [original_label_lookup.get(c, c) for c in ordered_cols]
        df["target"] = 0
        for i, col in enumerate(ordered_cols, start=1):
            df.loc[df[col] == 1, "target"] = i
        df = df.drop(columns=binary_indicator_cols)
    else:
        df = df.rename(columns={target_col: "target"})
        if df["target"].dtype == object or str(df["target"].dtype) == "category":
            target_le = LabelEncoder()
            df["target"] = target_le.fit_transform(df["target"].astype(str))
            class_names = list(target_le.classes_)
        else:
            uniques = sorted(df["target"].dropna().unique())
            target_map = {v: i for i, v in enumerate(uniques)}
            df["target"] = df["target"].map(target_map)
            class_names = [str(v) for v in uniques]

    df = df.dropna(subset=["target"]).reset_index(drop=True)
    df["target"] = df["target"].astype(int)

    feature_cols = [c for c in df.columns if c != "target"]
    numeric_cols = df[feature_cols].select_dtypes(include=np.number).columns.tolist()
    categorical_cols = [c for c in feature_cols if c not in numeric_cols]

    for c in numeric_cols:
        if df[c].isnull().any():
            df[c] = df[c].fillna(df[c].median())
    for c in categorical_cols:
        if df[c].isnull().any():
            df[c] = df[c].fillna(df[c].mode().iloc[0])
        le = LabelEncoder()
        df[c] = le.fit_transform(df[c].astype(str))

    return df, feature_cols, numeric_cols, categorical_cols, class_names
