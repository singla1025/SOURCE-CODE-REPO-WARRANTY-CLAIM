# checkpoints/

Not used by the current XGBoost / scikit-learn models (tree ensembles
train in a single `.fit()` call, not epoch-by-epoch). This folder is kept
for structural consistency and as the natural home for checkpoint files
if the project later adds a neural-network component (e.g. PyTorch/Keras
`.pt` / `.h5` checkpoints during training).
